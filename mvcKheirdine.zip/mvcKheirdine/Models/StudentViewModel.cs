using System;
using System.ComponentModel.DataAnnotations;

namespace mvc.Models
{
    public class StudentViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Le prénom est requis")]
        [Display(Name = "Prénom")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Le nom est requis")]
        [Display(Name = "Nom")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "L'âge est requis")]
        [Range(16, 99, ErrorMessage = "L'âge doit être entre 16 et 99 ans")]
        [Display(Name = "Âge")]
        public int Age { get; set; }

        [Required(ErrorMessage = "La spécialité est requise")]
        [Display(Name = "Spécialité")]
        public string Specialite { get; set; }  // Changed from enum to string

        [Required(ErrorMessage = "La date d'admission est requise")]
        [Display(Name = "Date d'admission")]
        [DataType(DataType.Date)]
        public DateTime AdmissionDate { get; set; }
    }
}
