

public class TestModel
{
    // This is a field
    public string? TestField;

    // This is a test property
    public string? TestProperty { get; set; }
}