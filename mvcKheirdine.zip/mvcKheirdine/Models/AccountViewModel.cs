using System.ComponentModel.DataAnnotations;

namespace mvc.Models
{
    public class AccountViewModel
    {
        [Required(ErrorMessage = "L'email est requis")]
        [EmailAddress(ErrorMessage = "Format d'email invalide")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Le mot de passe est requis")]
        [StringLength(100, ErrorMessage = "Le mot de passe doit contenir au moins {2} caractères.", MinimumLength = 6)]
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Les mots de passe ne correspondent pas")]
        public string ConfirmedPassword { get; set; }

        [Required(ErrorMessage = "Le prénom est requis")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Le nom est requis")]
        public string Lastname { get; set; }

        public string? PersonalWebSite { get; set; }
    }
}