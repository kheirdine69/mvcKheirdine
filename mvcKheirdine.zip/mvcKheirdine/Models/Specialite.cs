namespace mvc.Models
{
    public enum Specialite
    {
        Informatique,
        Mathematiques,
        Physique,
        Chimie,
        Biologie,
        Economie,
        Droit,
        Lettres,
        LanguesEtrangeres,
        Sciences
    }
} 