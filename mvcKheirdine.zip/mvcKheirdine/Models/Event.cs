using System;
using System.ComponentModel.DataAnnotations;

namespace mvc.Models
{
    public class Event
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Le titre est requis")]
        public string Title { get; set; }

        public string Description { get; set; }

        [Required(ErrorMessage = "La date est requise")]
        public DateTime EventDate { get; set; }

        [Required(ErrorMessage = "Le nombre maximum de participants est requis")]
        public int MaxParticipants { get; set; }

        [Required(ErrorMessage = "Le lieu est requis")]
        public string Location { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
