using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace mvc.Models;

public class Teacher : IdentityUser
{
    [Required(ErrorMessage = "Le prénom est requis")]
    [Display(Name = "Prénom")]
    public string Firstname { get; set; }

    [Required(ErrorMessage = "Le nom est requis")]
    [Display(Name = "Nom")]
    public string Lastname { get; set; }

    [Display(Name = "Site web personnel")]
    public string? PersonalWebSite { get; set; }
    // Add any other properties you need
}