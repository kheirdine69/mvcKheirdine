using System;
using System.ComponentModel.DataAnnotations;

namespace mvc.Models;

public class Student
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Le prénom est requis")]
    public string Firstname { get; set; }

    [Required(ErrorMessage = "Le nom est requis")]
    public string Lastname { get; set; }

    [Required(ErrorMessage = "L'âge est requis")]
    public int Age { get; set; }

    [Required(ErrorMessage = "La spécialité est requise")]
    public string Specialite { get; set; }

    [Required(ErrorMessage = "La date d'admission est requise")]
    public DateTime AdmissionDate { get; set; }
}
