using System.ComponentModel.DataAnnotations;

namespace mvc.Models
{
    public class TeacherViewModel
    {
        public string? Id { get; set; }

        [Required(ErrorMessage = "Le prénom est requis")]
        [Display(Name = "Prénom")]
        public string Firstname { get; set; } = string.Empty;

        [Required(ErrorMessage = "Le nom est requis")]
        [Display(Name = "Nom")]
        public string Lastname { get; set; } = string.Empty;

        [Required(ErrorMessage = "L'email est requis")]
        [EmailAddress(ErrorMessage = "Format d'email invalide")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Url(ErrorMessage = "Format d'URL invalide")]
        [Display(Name = "Site web personnel")]
        public string? PersonalWebSite { get; set; }

        [Display(Name = "Mot de passe")]
        public string? Password { get; set; }
    }
}
